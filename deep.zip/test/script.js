// Smooth Parallax Scrolling
window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;
  document.querySelectorAll('.section').forEach(section => {
      const speed = 0.5;
      section.style.transform = `translateY(-${scrollY * speed}px)`;
  });
});

// Form Submission (Basic Alert for Demo)
document.querySelector('.contact-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  alert('Message sent! We’ll get back to you soon.');
});

// Hero Animation (Simple Rotation for Demo)
const heroAnimation = document.querySelector('.hero-animation');
let rotation = 0;
setInterval(() => {
  rotation += 1;
  heroAnimation.style.transform = `rotate(${rotation}deg)`;
}, 16);