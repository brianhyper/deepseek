<?php
session_start();

// Database Configuration
$host = 'localhost';
$db   = 'hyperbrains_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Admin Authentication
if (!isset($_SESSION['admin_id'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND is_admin = TRUE');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            header("Location: admin_panel.php");
            exit;
        } else {
            $error = "Invalid admin credentials.";
        }
    }

    // Show Login Form
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Login | HyperBrains</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            :root {
                --primary: #0cf;
                --secondary: #6a00ff;
                --accent: #ff00aa;
                --dark: #0a0a14;
                --darker: #050510;
                --text: rgba(255, 255, 255, 0.9);
                --glass: rgba(15, 15, 30, 0.5);
                --glass-border: rgba(255, 255, 255, 0.1);
                --background: var(--darker);
                --surface: var(--dark);
            }
            
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: 'Segoe UI', system-ui, sans-serif;
            }
            
            body {
                background-color: var(--background);
                color: var(--text);
                overflow-x: hidden;
                height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            
            .login-container {
                background: var(--glass);
                backdrop-filter: blur(10px);
                border: 1px solid var(--glass-border);
                border-radius: 15px;
                padding: 2rem;
                width: 400px;
                max-width: 90%;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            }
            
            .login-header {
                text-align: center;
                margin-bottom: 2rem;
            }
            
            .login-header h1 {
                background: linear-gradient(90deg, var(--primary), var(--secondary));
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
                margin-bottom: 0.5rem;
            }
            
            .login-header i {
                font-size: 3rem;
                margin-bottom: 1rem;
                background: linear-gradient(90deg, var(--primary), var(--secondary));
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
            }
            
            .form-group {
                margin-bottom: 1.5rem;
            }
            
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 500;
            }
            
            .form-control {
                width: 100%;
                padding: 1rem;
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid var(--glass-border);
                border-radius: 8px;
                color: var(--text);
                font-size: 1rem;
                transition: all 0.3s ease;
            }
            
            .form-control:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 10px rgba(0, 204, 255, 0.2);
            }
            
            .cta-button {
                background: linear-gradient(90deg, var(--primary), var(--secondary));
                color: white;
                border: none;
                padding: 0.8rem 1.5rem;
                border-radius: 50px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                box-shadow: 0 0 15px rgba(0, 204, 255, 0.3);
                width: 100%;
            }
            
            .cta-button:hover {
                transform: translateY(-3px);
                box-shadow: 0 0 25px rgba(0, 204, 255, 0.5);
            }
            
            .error-message {
                color: #ff4d4d;
                margin-top: 1rem;
                text-align: center;
            }
            
            .floating-orb {
                position: fixed;
                border-radius: 50%;
                filter: blur(40px);
                opacity: 0.3;
                z-index: -1;
            }
            
            .orb-1 {
                width: 300px;
                height: 300px;
                background: var(--primary);
                top: 20%;
                left: 10%;
                animation: float 8s ease-in-out infinite;
            }
            
            .orb-2 {
                width: 200px;
                height: 200px;
                background: var(--secondary);
                bottom: 10%;
                right: 20%;
                animation: float 6s ease-in-out infinite 2s;
            }
            
            @keyframes float {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-30px); }
            }
        </style>
    </head>
    <body>
        <div class="floating-orb orb-1"></div>
        <div class="floating-orb orb-2"></div>
        
        <div class="login-container">
            <div class="login-header">
                <i class="fas fa-brain"></i>
                <h1>HyperBrains Admin</h1>
                <p>Enter your credentials to continue</p>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="admin@hyperbrains.io" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
                
                <button type="submit" name="login" class="cta-button">Login</button>
                
                <?php if (isset($error)): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Delete Chat
    if (isset($_POST['delete_chat'])) {
        $stmt = $pdo->prepare('DELETE FROM chats WHERE id = ?');
        $stmt->execute([$_POST['chat_id']]);
        $_SESSION['message'] = 'Chat deleted successfully';
        header("Location: admin_panel.php");
        exit;
    }
    // Ban/Unban User
    elseif (isset($_POST['toggle_ban'])) {
        $stmt = $pdo->prepare('UPDATE users SET is_banned = NOT is_banned WHERE id = ?');
        $stmt->execute([$_POST['user_id']]);
        $action = $_POST['is_banned'] ? 'unbanned' : 'banned';
        $_SESSION['message'] = 'User '.$action.' successfully';
        header("Location: admin_panel.php");
        exit;
    }
    // Export to CSV
    elseif (isset($_POST['export_csv'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="hyperbrains_data_'.date('Y-m-d').'.csv"');
        
        $output = fopen('php://output', 'w');
        
        if ($_POST['export_type'] === 'users') {
            fputcsv($output, ['ID', 'Name', 'Email', 'Joined', 'Status']);
            $users = $pdo->query('SELECT id, name, email, created_at, is_banned FROM users')->fetchAll();
            foreach ($users as $user) {
                fputcsv($output, [
                    $user['id'],
                    $user['name'],
                    $user['email'],
                    $user['created_at'],
                    $user['is_banned'] ? 'Banned' : 'Active'
                ]);
            }
        } else {
            fputcsv($output, ['ID', 'User', 'Message', 'Response', 'Timestamp']);
            $chats = $pdo->query('
                SELECT chats.id, IFNULL(users.email, "Guest") as user, 
                       chats.message, chats.response, chats.timestamp 
                FROM chats LEFT JOIN users ON chats.user_id = users.id
            ')->fetchAll();
            foreach ($chats as $chat) {
                fputcsv($output, $chat);
            }
        }
        
        fclose($output);
        exit;
    }
    // Add Event
    elseif (isset($_POST['add_event'])) {
        // In a real implementation, you would save to database
        $_SESSION['message'] = 'Event added successfully';
        header("Location: admin_panel.php");
        exit;
    }
    // Logout
    elseif (isset($_POST['logout'])) {
        session_destroy();
        header("Location: admin_panel.php");
        exit;
    }
}

// Pagination & Filtering
$current_page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$per_page = 10;

// Users Filter
$user_search = isset($_GET['user_search']) ? $_GET['user_search'] : '';
$user_query = 'SELECT * FROM users';
$user_params = [];
if (!empty($user_search)) {
    $user_query .= ' WHERE name LIKE ? OR email LIKE ?';
    $user_params = ["%$user_search%", "%$user_search%"];
}

// Chats Filter
$chat_search = isset($_GET['chat_search']) ? $_GET['chat_search'] : '';
$chat_query = 'SELECT chats.*, IFNULL(users.email, "Guest") as user_email FROM chats LEFT JOIN users ON chats.user_id = users.id';
$chat_params = [];
if (!empty($chat_search)) {
    $chat_query .= ' WHERE chats.message LIKE ? OR chats.response LIKE ? OR users.email LIKE ?';
    $chat_params = ["%$chat_search%", "%$chat_search%", "%$chat_search%"];
}

// Get Total Counts for Pagination
$total_users = $pdo->prepare(str_replace('*', 'COUNT(*)', $user_query));
$total_users->execute($user_params);
$total_users = $total_users->fetchColumn();

$total_chats = $pdo->prepare(str_replace('chats.*, IFNULL(users.email, "Guest") as user_email', 'COUNT(*)', $chat_query));
$total_chats->execute($chat_params);
$total_chats = $total_chats->fetchColumn();

// Apply Pagination
$user_query .= " LIMIT " . (($current_page - 1) * $per_page) . ", $per_page";
$chat_query .= " ORDER BY chats.timestamp DESC LIMIT " . (($current_page - 1) * $per_page) . ", $per_page";

// Fetch Data
$users = $pdo->prepare($user_query);
$users->execute($user_params);
$users = $users->fetchAll();

$chats = $pdo->prepare($chat_query);
$chats->execute($chat_params);
$chats = $chats->fetchAll();

// Calendar Events (Example Data)
$events = [
    ['id' => 1, 'title' => 'Project Deadline', 'date' => date('Y-m-d', strtotime('+3 days')), 'color' => '#ff00aa'],
    ['id' => 2, 'title' => 'Client Meeting', 'date' => date('Y-m-d', strtotime('+5 days')), 'color' => '#0cf'],
    ['id' => 3, 'title' => 'Team Sync', 'date' => date('Y-m-d'), 'color' => '#6a00ff'],
];

// Time Tracking (Example Data)
$time_entries = [
    ['id' => 1, 'project' => 'Website Redesign', 'user' => 'Alex M.', 'start' => '09:00', 'end' => '12:30', 'date' => date('Y-m-d')],
    ['id' => 2, 'project' => 'Mobile App', 'user' => 'David K.', 'start' => '10:15', 'end' => '15:45', 'date' => date('Y-m-d')],
    ['id' => 3, 'project' => 'Branding', 'user' => 'Sarah J.', 'start' => '13:00', 'end' => '17:00', 'date' => date('Y-m-d')],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | HyperBrains</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0cf;
            --secondary: #6a00ff;
            --accent: #ff00aa;
            --dark: #0a0a14;
            --darker: #050510;
            --text: rgba(255, 255, 255, 0.9);
            --glass: rgba(15, 15, 30, 0.5);
            --glass-border: rgba(255, 255, 255, 0.1);
            --background: var(--darker);
            --surface: var(--dark);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background-color: var(--background);
            color: var(--text);
            overflow-x: hidden;
        }
        
        /* Header */
        .admin-header {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--glass-border);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .admin-header h1 {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .admin-header i {
            font-size: 1.5rem;
        }
        
        .logout-btn {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            background: rgba(255, 0, 0, 0.2);
            border-color: #ff4d4d;
        }
        
        /* Main Container */
        .admin-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: calc(100vh - 60px);
        }
        
        /* Sidebar */
        .admin-sidebar {
            background: var(--glass);
            border-right: 1px solid var(--glass-border);
            padding: 1.5rem;
        }
        
        .admin-nav {
            list-style: none;
            margin-top: 2rem;
        }
        
        .admin-nav li {
            margin-bottom: 0.5rem;
        }
        
        .admin-nav a {
            display: block;
            padding: 0.8rem 1rem;
            color: var(--text);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background: rgba(0, 204, 255, 0.1);
            color: var(--primary);
        }
        
        .admin-nav a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        /* Main Content */
        .admin-content {
            padding: 2rem;
        }
        
        /* Cards */
        .admin-card {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            transition: all 0.3s ease;
        }
        
        .admin-card:hover {
            box-shadow: 0 10px 30px rgba(0, 204, 255, 0.1);
            border-color: rgba(0, 204, 255, 0.3);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .card-header h2 {
            font-size: 1.5rem;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        /* Tables */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .admin-table th {
            background: rgba(0, 204, 255, 0.2);
            text-align: left;
            padding: 1rem;
            font-weight: 600;
        }
        
        .admin-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .admin-table tr:last-child td {
            border-bottom: none;
        }
        
        .admin-table tr:hover {
            background: rgba(0, 204, 255, 0.05);
        }
        
        /* Buttons */
        .btn {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            font-size: 0.9rem;
        }
        
        .btn-primary {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            box-shadow: 0 0 15px rgba(0, 204, 255, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 0 25px rgba(0, 204, 255, 0.5);
        }
        
        .btn-danger {
            background: rgba(255, 0, 85, 0.2);
            color: #ff4d4d;
            border: 1px solid rgba(255, 0, 85, 0.3);
        }
        
        .btn-danger:hover {
            background: rgba(255, 0, 85, 0.3);
        }
        
        .btn-success {
            background: rgba(0, 200, 83, 0.2);
            color: #00c853;
            border: 1px solid rgba(0, 200, 83, 0.3);
        }
        
        .btn-success:hover {
            background: rgba(0, 200, 83, 0.3);
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            font-size: 0.8rem;
        }
        
        /* Search & Filters */
        .search-box {
            display: flex;
            gap: 10px;
            margin-bottom: 1.5rem;
        }
        
        .search-input {
            flex: 1;
            padding: 0.8rem 1rem;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            border-radius: 50px;
            color: var(--text);
            transition: all 0.3s ease;
        }
        
        .search-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 10px rgba(0, 204, 255, 0.2);
        }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 2rem;
        }
        
        .page-link {
            display: inline-block;
            padding: 0.5rem 0.8rem;
            background: var(--glass);
            border: 1px solid var(--glass-border);
            border-radius: 5px;
            color: var(--text);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .page-link:hover, .page-link.active {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white;
            border-color: transparent;
        }
        
        /* Calendar */
        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
            margin-top: 1rem;
        }
        
        .calendar-header {
            grid-column: span 7;
            text-align: center;
            font-weight: 600;
            padding: 0.5rem;
            background: rgba(0, 204, 255, 0.1);
            border-radius: 5px;
        }
        
        .calendar-day {
            padding: 0.5rem;
            text-align: center;
            border-radius: 5px;
        }
        
        .calendar-day.empty {
            visibility: hidden;
        }
        
        .calendar-day.today {
            background: rgba(0, 204, 255, 0.2);
            font-weight: 600;
        }
        
        .calendar-day.has-event {
            position: relative;
        }
        
        .calendar-day.has-event::after {
            content: '';
            position: absolute;
            bottom: 5px;
            left: 50%;
            transform: translateX(-50%);
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: var(--primary);
        }
        
        .event-list {
            margin-top: 1rem;
        }
        
        .event-item {
            display: flex;
            align-items: center;
            padding: 0.8rem;
            margin-bottom: 0.5rem;
            background: var(--glass);
            border-radius: 8px;
            border-left: 3px solid var(--primary);
        }
        
        .event-color {
            width: 15px;
            height: 15px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        /* Time Tracking */
        .time-entry {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: var(--glass);
            border-radius: 8px;
            margin-bottom: 0.5rem;
        }
        
        .time-info {
            flex: 1;
        }
        
        .time-range {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .time-duration {
            background: rgba(0, 204, 255, 0.1);
            padding: 0.3rem 0.6rem;
            border-radius: 50px;
            font-size: 0.8rem;
        }
        
        /* Floating Orbs */
        .floating-orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(40px);
            opacity: 0.3;
            z-index: -1;
        }
        
        .orb-1 {
            width: 300px;
            height: 300px;
            background: var(--primary);
            top: 20%;
            left: 10%;
            animation: float 8s ease-in-out infinite;
        }
        
        .orb-2 {
            width: 200px;
            height: 200px;
            background: var(--secondary);
            bottom: 10%;
            right: 20%;
            animation: float 6s ease-in-out infinite 2s;
        }
        
        .orb-3 {
            width: 150px;
            height: 150px;
            background: var(--accent);
            top: 70%;
            left: 30%;
            animation: float 7s ease-in-out infinite 1s;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-30px); }
        }
        
        /* Message Alert */
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            background: rgba(0, 204, 255, 0.2);
            border-left: 3px solid var(--primary);
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .admin-container {
                grid-template-columns: 1fr;
            }
            
            .admin-sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Floating Background Orbs -->
    <div class="floating-orb orb-1"></div>
    <div class="floating-orb orb-2"></div>
    <div class="floating-orb orb-3"></div>
    
    <!-- Admin Header -->
    <header class="admin-header">
        <h1><i class="fas fa-brain"></i> HyperBrains Admin</h1>
        <form method="POST">
            <button type="submit" name="logout" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        </form>
    </header>
    
    <!-- Main Container -->
    <div class="admin-container">
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <div class="admin-profile">
                <h3>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></h3>
                <p>Last login: <?php echo date('Y-m-d H:i'); ?></p>
            </div>
            
            <ul class="admin-nav">
                <li><a href="#dashboard" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="#users"><i class="fas fa-users"></i> Users</a></li>
                <li><a href="#chats"><i class="fas fa-comments"></i> Chats</a></li>
                <li><a href="#calendar"><i class="fas fa-calendar-alt"></i> Calendar</a></li>
                <li><a href="#time-tracking"><i class="fas fa-clock"></i> Time Tracking</a></li>
                <li><a href="#settings"><i class="fas fa-cog"></i> Settings</a></li>
            </ul>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-content">
            <?php if (isset($_SESSION['message'])): ?>
            <div class="alert">
                <?php echo htmlspecialchars($_SESSION['message']); unset($_SESSION['message']); ?>
            </div>
            <?php endif; ?>
            
            <!-- Dashboard Overview -->
            <section id="dashboard">
                <div class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-tachometer-alt"></i> Dashboard Overview</h2>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div class="admin-card">
                            <h3>Total Users</h3>
                            <p style="font-size: 2.5rem; font-weight: 700; background: linear-gradient(90deg, var(--primary), var(--secondary)); -webkit-background-clip: text; background-clip: text; color: transparent;">
                                <?php echo $total_users; ?>
                            </p>
                        </div>
                        
                        <div class="admin-card">
                            <h3>Total Chats</h3>
                            <p style="font-size: 2.5rem; font-weight: 700; background: linear-gradient(90deg, var(--primary), var(--secondary)); -webkit-background-clip: text; background-clip: text; color: transparent;">
                                <?php echo $total_chats; ?>
                            </p>
                        </div>
                        
                        <div class="admin-card">
                            <h3>Active Projects</h3>
                            <p style="font-size: 2.5rem; font-weight: 700; background: linear-gradient(90deg, var(--primary), var(--secondary)); -webkit-background-clip: text; background-clip: text; color: transparent;">
                                12
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- Users Section -->
            <section id="users">
                <div class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-users"></i> User Management</h2>
                        <div>
                            <form method="GET" class="search-box">
                                <input type="text" name="user_search" class="search-input" placeholder="Search users..." value="<?php echo htmlspecialchars($user_search); ?>">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </form>
                        </div>
                    </div>
                    
                    <div style="overflow-x: auto;">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Joined</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <span style="color: <?php echo $user['is_banned'] ? '#ff4d4d' : '#00c853'; ?>">
                                            <?php echo $user['is_banned'] ? 'Banned' : 'Active'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="is_banned" value="<?php echo $user['is_banned']; ?>">
                                            <button type="submit" name="toggle_ban" class="btn btn-sm <?php echo $user['is_banned'] ? 'btn-success' : 'btn-danger'; ?>">
                                                <?php echo $user['is_banned'] ? 'Unban' : 'Ban'; ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination">
                        <?php for ($i = 1; $i <= ceil($total_users / $per_page); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&user_search=<?php echo urlencode($user_search); ?>" class="page-link <?php echo $i == $current_page ? 'active' : ''; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                    
                    <!-- Export Button -->
                    <form method="POST" style="margin-top: 1rem;">
                        <input type="hidden" name="export_type" value="users">
                        <button type="submit" name="export_csv" class="btn btn-primary">
                            <i class="fas fa-download"></i> Export to CSV
                        </button>
                    </form>
                </div>
            </section>
            
            <!-- Chats Section -->
            <section id="chats">
                <div class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-comments"></i> Chat Moderation</h2>
                        <div>
                            <form method="GET" class="search-box">
                                <input type="text" name="chat_search" class="search-input" placeholder="Search chats..." value="<?php echo htmlspecialchars($chat_search); ?>">
                                <button type="submit" class="btn btn-primary">Search</button>
                            </form>
                        </div>
                    </div>
                    
                    <div style="overflow-x: auto;">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Message</th>
                                    <th>Response</th>
                                    <th>Timestamp</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($chats as $chat): ?>
                                <tr>
                                    <td><?php echo $chat['id']; ?></td>
                                    <td><?php echo htmlspecialchars($chat['user_email']); ?></td>
                                    <td><?php echo htmlspecialchars(mb_strimwidth($chat['message'], 0, 50, '...')); ?></td>
                                    <td><?php echo htmlspecialchars(mb_strimwidth($chat['response'], 0, 50, '...')); ?></td>
                                    <td><?php echo date('M j, H:i', strtotime($chat['timestamp'])); ?></td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="chat_id" value="<?php echo $chat['id']; ?>">
                                            <button type="submit" name="delete_chat" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination">
                        <?php for ($i = 1; $i <= ceil($total_chats / $per_page); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&chat_search=<?php echo urlencode($chat_search); ?>" class="page-link <?php echo $i == $current_page ? 'active' : ''; ?>">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                    
                    <!-- Export Button -->
                    <form method="POST" style="margin-top: 1rem;">
                        <input type="hidden" name="export_type" value="chats">
                        <button type="submit" name="export_csv" class="btn btn-primary">
                            <i class="fas fa-download"></i> Export to CSV
                        </button>
                    </form>
                </div>
            </section>
            
            <!-- Calendar Section -->
            <section id="calendar">
                <div class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-calendar-alt"></i> Production Calendar</h2>
                        <button class="btn btn-primary" onclick="document.getElementById('eventModal').style.display='block'">
                            <i class="fas fa-plus"></i> Add Event
                        </button>
                    </div>
                    
                    <!-- Mini Calendar -->
                    <div class="calendar">
                        <div class="calendar-header">
                            <?php echo date('F Y'); ?>
                        </div>
                        
                        <?php
                        $days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                        foreach ($days as $day): ?>
                            <div class="calendar-day"><?php echo $day; ?></div>
                        <?php endforeach; ?>
                        
                        <?php
                        $first_day = date('w', strtotime(date('Y-m-01')));
                        $days_in_month = date('t');
                        
                        for ($i = 0; $i < $first_day; $i++): ?>
                            <div class="calendar-day empty"></div>
                        <?php endfor; ?>
                        
                        <?php for ($day = 1; $day <= $days_in_month; $day++): 
                            $date = date('Y-m-') . str_pad($day, 2, '0', STR_PAD_LEFT);
                            $has_event = in_array($date, array_column($events, 'date'));
                            $is_today = $date == date('Y-m-d');
                        ?>
                            <div class="calendar-day <?php echo $is_today ? 'today' : ''; ?> <?php echo $has_event ? 'has-event' : ''; ?>">
                                <?php echo $day; ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                    
                    <!-- Upcoming Events -->
                    <div class="event-list">
                        <h3 style="margin-top: 2rem; margin-bottom: 1rem;">Upcoming Events</h3>
                        
                        <?php foreach ($events as $event): ?>
                        <div class="event-item">
                            <div class="event-color" style="background: <?php echo $event['color']; ?>"></div>
                            <div style="flex: 1;">
                                <strong><?php echo $event['title']; ?></strong>
                                <div style="font-size: 0.9rem; opacity: 0.8;">
                                    <?php echo date('D, M j, Y', strtotime($event['date'])); ?>
                                </div>
                            </div>
                            <button class="btn btn-sm btn-danger">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
            
            <!-- Time Tracking Section -->
            <section id="time-tracking">
                <div class="admin-card">
                    <div class="card-header">
                        <h2><i class="fas fa-clock"></i> Time Tracking</h2>
                        <button class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Entry
                        </button>
                    </div>
                    
                    <div style="margin-top: 1rem;">
                        <h3>Today's Time Entries</h3>
                        
                        <?php foreach ($time_entries as $entry): 
                            $start = strtotime($entry['date'] . ' ' . $entry['start']);
                            $end = strtotime($entry['date'] . ' ' . $entry['end']);
                            $duration = round(($end - $start) / 3600, 2);
                        ?>
                        <div class="time-entry">
                            <div class="time-info">
                                <strong><?php echo $entry['project']; ?></strong>
                                <div class="time-range">
                                    <?php echo $entry['user']; ?> • 
                                    <?php echo date('g:i A', $start); ?> - <?php echo date('g:i A', $end); ?>
                                </div>
                            </div>
                            <div class="time-duration">
                                <?php echo $duration; ?> hrs
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
        </main>
    </div>
    
    <!-- Add Event Modal -->
    <div id="eventModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center;">
        <div style="background: var(--glass); padding: 2rem; border-radius: 15px; width: 500px; max-width: 90%;">
            <h2>Add New Event</h2>
            <form method="POST">
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem;">Event Title</label>
                    <input type="text" name="event_title" class="form-control" required>
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem;">Date</label>
                    <input type="date" name="event_date" class="form-control" required>
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: block; margin-bottom: 0.5rem;">Color</label>
                    <select name="event_color" class="form-control">
                        <option value="#0cf">Blue</option>
                        <option value="#6a00ff">Purple</option>
                        <option value="#ff00aa">Pink</option>
                    </select>
                </div>
                <div style="display: flex; gap: 10px; margin-top: 1rem;">
                    <button type="button" class="btn btn-danger" onclick="document.getElementById('eventModal').style.display='none'">Cancel</button>
                    <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Confirm before actions
        document.querySelectorAll('form[method="POST"]').forEach(form => {
            form.addEventListener('submit', (e) => {
                if (form.querySelector('[name="delete_chat"]') || 
                    form.querySelector('[name="toggle_ban"]')) {
                    const action = form.querySelector('[name="delete_chat"]') ? 'delete' : 
                                  (form.querySelector('[name="toggle_ban"]').textContent.toLowerCase());
                    if (!confirm(`Are you sure you want to ${action} this?`)) {
                        e.preventDefault();
                    }
                }
            });
        });
        
        // Toggle sidebar on mobile
        const sidebarToggle = document.createElement('button');
        sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        sidebarToggle.style.position = 'fixed';
        sidebarToggle.style.bottom = '20px';
        sidebarToggle.style.right = '20px';
        sidebarToggle.style.zIndex = '99';
        sidebarToggle.style.background = 'var(--primary)';
        sidebarToggle.style.color = 'white';
        sidebarToggle.style.border = 'none';
        sidebarToggle.style.borderRadius = '50%';
        sidebarToggle.style.width = '50px';
        sidebarToggle.style.height = '50px';
        sidebarToggle.style.fontSize = '1.2rem';
        sidebarToggle.style.cursor = 'pointer';
        sidebarToggle.style.boxShadow = '0 0 15px rgba(0, 204, 255, 0.5)';
        
        sidebarToggle.addEventListener('click', () => {
            document.querySelector('.admin-sidebar').style.display = 
                document.querySelector('.admin-sidebar').style.display === 'none' ? 'block' : 'none';
        });
        
        document.body.appendChild(sidebarToggle);
        
        // Hide sidebar on mobile by default
        if (window.innerWidth < 992) {
            document.querySelector('.admin-sidebar').style.display = 'none';
        }
    </script>
</body>
</html>